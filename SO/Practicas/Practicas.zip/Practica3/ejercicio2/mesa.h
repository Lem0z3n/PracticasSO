#ifndef MESA_H
#define MESA_H

struct t_mesa{
	int cook_waiting;
	int savages_waiting;
	int comida;
  int finish;
};

#endif